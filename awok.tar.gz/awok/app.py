from flask import Flask, render_template, request, redirect, url_for

from flask_sqlalchemy import SQLAlchemy

from config import Config
from routes import app_routes
from models import db, User
from flask_migrate import Migrate
from flask_login import LoginManager


def create_app():
   app = Flask(__name__)

   app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://erp_user:Skills39@localhost/erp'

   app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

   app.config['SECRET_KEY'] = 'supersecretkey'

   db.init_app(app)

   migrate = Migrate(app, db)


   app.register_blueprint(app_routes)
   return app


app = create_app()


login_manager=LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
   return User.query.get(int(user_id))



if __name__ == '__main__':
    with app.app_context():
     db.create_all()
    app.run(debug=True)
