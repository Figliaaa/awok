import os

class Config:
    SECRET_KEY = 'supersecretkey'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://erp_user:Skills39@localhost/erp'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    LOG_FILE = 'logs/error.log'

